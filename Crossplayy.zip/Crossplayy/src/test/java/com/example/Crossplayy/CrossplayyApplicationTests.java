package com.example.Crossplayy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrossplayyApplicationTests {

	@Test
	void contextLoads() {
	}

}

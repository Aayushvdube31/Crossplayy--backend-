package com.example.Crossplayy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrossplayyApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrossplayyApplication.class, args);
	}

}
